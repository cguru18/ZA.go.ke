const express = require('express');
const router = express.Router();
const Product = require('../models/Product');

router.get('/', async (req, res) => {
    try {
        const { unlocked } = req.query;
        let query = {};
        
        // If not unlocked, only show normal products
        if (unlocked !== 'true') {
            query.isInfused = false;
        }

        const products = await Product.find(query);
        res.json(products);
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;
