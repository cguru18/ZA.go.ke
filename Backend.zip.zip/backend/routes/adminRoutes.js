const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Order = require('../models/Order');
const AccessCode = require('../models/AccessCode');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');

const { protect, admin } = require('../middleware/authMiddleware');

// POST /api/admin/signup
router.post('/signup', async (req, res) => {
    const { fullName, email, password, masterPassword } = req.body;

    const MASTER_PASSWORD = process.env.MASTER_PASSWORD || 'HEAT_AND_TREATS_2026';

    if (masterPassword !== MASTER_PASSWORD) {
        return res.status(403).json({ success: false, message: 'Invalid Master Password.' });
    }

    try {
        const userExists = await User.findOne({ email });
        if (userExists) {
            return res.status(400).json({ success: false, message: 'User already exists' });
        }

        // Generate Dual-Key AES-256 equivalent
        const rawEncryptionKey = crypto.randomBytes(32).toString('hex');
        
        // Hash the encryption key to store safely
        const salt = await bcrypt.genSalt(12);
        const adminSecretHash = await bcrypt.hash(rawEncryptionKey, salt);

        const adminUser = new User({
            fullName,
            email,
            password, // Mongoose pre-save hook will hash this
            role: 'ADMIN',
            adminSecretHash,
            permissions: ['ALL']
        });

        await adminUser.save();

        res.status(201).json({
            success: true,
            message: 'Admin successfully created. SAVE YOUR ENCRYPTION KEY. IT WILL ONLY BE SHOWN ONCE.',
            encryptionKey: rawEncryptionKey
        });

    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// POST /api/admin/login
router.post('/login', async (req, res) => {
    const { email, password, encryptionKey } = req.body;

    try {
        const adminUser = await User.findOne({ email, role: 'ADMIN' });
        if (!adminUser) {
            return res.status(401).json({ success: false, message: 'Invalid Admin Credentials' });
        }

        // 1. Verify Password
        const isPasswordMatch = await adminUser.matchPassword(password);
        if (!isPasswordMatch) {
            return res.status(401).json({ success: false, message: 'Invalid Password' });
        }

        // 2. Verify Physical Encryption Key
        if (!adminUser.adminSecretHash || !encryptionKey) {
             return res.status(401).json({ success: false, message: 'Encryption Key Required' });
        }
        
        const isKeyMatch = await bcrypt.compare(encryptionKey, adminUser.adminSecretHash);
        if (!isKeyMatch) {
            return res.status(401).json({ success: false, message: 'Invalid Encryption Key' });
        }

        const token = jwt.sign({ id: adminUser._id, role: adminUser.role }, process.env.JWT_SECRET || 'secret123', {
            expiresIn: '30d'
        });

        res.status(200).json({
            success: true,
            token,
            admin: {
                id: adminUser._id,
                fullName: adminUser.fullName,
                email: adminUser.email,
                role: adminUser.role
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// Secure Admin Routes
router.use(protect);
router.use(admin);

// GET /api/admin/financial-summary
// Lightweight aggregation for the financial summary KPI card
router.get('/financial-summary', async (req, res) => {
    try {
        const report = await Order.aggregate([
            { $match: { paymentStatus: 'Completed' } },
            {
                $group: {
                    _id: null,
                    totalGross:  { $sum: '$grossRevenue' },
                    totalOrders: { $count: {} },
                    // Daraja takes 0.5% — calculate processing fees on the fly
                    totalFees:   { $sum: { $multiply: ['$grossRevenue', 0.005] } }
                }
            },
            {
                $project: {
                    _id: 0,
                    totalGross:  1,
                    totalOrders: 1,
                    totalFees:   1,
                    netRevenue:  { $subtract: ['$totalGross', '$totalFees'] }
                }
            }
        ]);

        res.json(report[0] || { totalGross: 0, totalOrders: 0, totalFees: 0, netRevenue: 0 });
    } catch (err) {
        res.status(500).json({ error: 'Aggregation Failed' });
    }
});

// GET /api/admin/reports
router.get('/reports', async (req, res) => {
    try {
        // Accounting Aggregation Pipeline
        const financials = await Order.aggregate([
            { $match: { paymentStatus: 'Completed' } },
            { 
                $group: { 
                    _id: null, 
                    totalGrossRevenue: { $sum: '$grossRevenue' },
                    totalProcessingFees: { $sum: { $multiply: ['$grossRevenue', 0.005] } } // 0.5% Daraja Fee
                } 
            }
        ]);

        const gross = financials.length > 0 ? financials[0].totalGrossRevenue : 0;
        const fees = financials.length > 0 ? financials[0].totalProcessingFees : 0;
        const net = gross - fees;

        // Traffic Metrics (Simulated sessions via recently created users in 24h as fallback)
        const last24h = new Date(new Date().getTime() - (24 * 60 * 60 * 1000));
        const trafficCount = await User.countDocuments({ createdAt: { $gte: last24h } });

        // Retrieve orders for the Accounting Table — include mpesaReceiptNumber for audit trail
        const recentOrders = await Order.find()
            .sort({ createdAt: -1 })
            .populate('customerId', 'fullName email')
            .select('orderId customerId grossRevenue processingFee netProfit paymentStatus mpesaReceiptNumber createdAt')
            .limit(50);

        res.status(200).json({
            success: true,
            kpis: {
                grossRevenue: gross,
                processingFees: fees,
                netProfit: net,
                traffic24h: trafficCount // strictly DB driven, no more mock Math.random()
            },
            orders: recentOrders
        });

    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// ── Mutex TTL: any lock held longer than this is considered stale ─────────────
const LOCK_TTL_MS = 30_000; // 30 seconds

// GET /api/admin/vault-code
// Returns the current active vault code for admin display (admin-only route).
router.get('/vault-code', async (req, res) => {
    try {
        const now = new Date();

        // Find the currently active, non-expired code
        let activeCode = await AccessCode.findOne({ isActive: true, expiresAt: { $gt: now } })
            .sort({ createdAt: -1 });

        // If none exists yet, auto-generate one so the dashboard is never empty
        if (!activeCode) {
            const rawCode  = crypto.randomBytes(3).toString('hex').toUpperCase();
            const expiresAt = new Date(now.getTime() + 24 * 60 * 60 * 1000);
            activeCode = await AccessCode.create({ code: rawCode, isActive: true, expiresAt });
            console.log(`[VAULT] Auto-generated first access code: ${activeCode.code}`);
        }

        return res.status(200).json({
            success:   true,
            code:      activeCode.code,
            expiresAt: activeCode.expiresAt,
            // Tell the UI if the code is currently being rotated by another admin
            isLocked:  !!(activeCode.lockedBy && (now - new Date(activeCode.lockedAt)) < LOCK_TTL_MS),
            lockedBy:  activeCode.lockedBy || null,
        });
    } catch (error) {
        console.error('vault-code fetch error:', error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// POST /api/admin/rotate-codes
// Atomically acquires a DB-level mutex before rotating, preventing concurrent
// changes by multiple admins across all cluster workers.
router.post('/rotate-codes', async (req, res) => {
    // The calling admin's email must be sent in the request body for the lock audit trail
    const adminEmail = req.body?.adminEmail || 'unknown-admin';

    try {
        const now        = new Date();
        const staleLimit = new Date(now.getTime() - LOCK_TTL_MS);

        // ── Step 1: Atomically acquire the lock ──────────────────────────────
        // We use findOneAndUpdate with a condition that only matches if:
        //   (a) no lock is held, OR
        //   (b) the existing lock is stale (older than LOCK_TTL_MS)
        // This is a single atomic MongoDB operation — safe across all workers.
        const lockedDoc = await AccessCode.findOneAndUpdate(
            {
                isActive: true,
                $or: [
                    { lockedBy: null },
                    { lockedAt: { $lt: staleLimit } }, // stale lock auto-release
                ],
            },
            {
                $set: { lockedBy: adminEmail, lockedAt: now },
            },
            { new: true, sort: { createdAt: -1 } }
        );

        // If no document was updated, another admin holds the lock right now
        if (!lockedDoc) {
            // Find the doc to report who locked it
            const blocker = await AccessCode.findOne({ isActive: true }).sort({ createdAt: -1 });
            const lockedByEmail = blocker?.lockedBy || 'another admin';
            return res.status(423).json({
                success: false,
                message: `Code change is locked by ${lockedByEmail}. Please wait a moment and try again.`,
            });
        }

        // ── Step 2: Deactivate all current codes and create a new one ────────
        await AccessCode.updateMany({ isActive: true, _id: { $ne: lockedDoc._id } }, { isActive: false });

        const newCode   = crypto.randomBytes(3).toString('hex').toUpperCase();
        const expiresAt = new Date(now.getTime() + 24 * 60 * 60 * 1000); // 24h from now

        const newRecord = await AccessCode.create({
            code:      newCode,
            isActive:  true,
            expiresAt,
            lockedBy:  null, // new code has no lock
            lockedAt:  null,
        });

        // ── Step 3: Deactivate the old locked doc (it's been replaced) ───────
        await AccessCode.findByIdAndUpdate(lockedDoc._id, { isActive: false, lockedBy: null, lockedAt: null });

        console.log(`[VAULT] Code rotated by ${adminEmail}. New code: ${newCode}`);

        return res.status(200).json({
            success:   true,
            newCode,
            expiresAt: newRecord.expiresAt,
            message:   'Vault access code successfully changed.',
        });
    } catch (error) {
        console.error('rotate-codes error:', error);
        // Always release the lock on error to avoid a deadlock
        try {
            await AccessCode.updateMany({ lockedBy: adminEmail }, { lockedBy: null, lockedAt: null });
        } catch (_) {}
        res.status(500).json({ success: false, message: 'Server error during code rotation.' });
    }
});

module.exports = router;
