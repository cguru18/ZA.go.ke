/**
 * SecureCodeService.js
 * ────────────────────────────────────────────────────────────────────────────
 * Provides cryptographically-secure access code generation, hashing,
 * verification and audit logging for the ZA.go.ke platform.
 *
 * Design decisions:
 *  • Base32 alphabet (no I/O/1/0 to avoid visual confusion)
 *  • crypto.randomBytes → guaranteed OS entropy, not Math.random
 *  • bcrypt (rounds=12) for storage → safe even if DB is compromised
 *  • Every event (generate / verify-ok / verify-fail) is written to
 *    CodeAuditLog for forensic trail across cluster workers
 */

const crypto    = require('crypto');
const bcrypt    = require('bcryptjs');
const CodeAuditLog = require('../models/CodeAuditLog');

// Base32 alphabet: RFC 4648 minus I O 1 0 to avoid user confusion
const BASE32_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const BCRYPT_ROUNDS   = 12;

/**
 * generateCode(length = 8)
 * Returns a random Base32-encoded access code of `length` characters.
 * Uses OS-level entropy via crypto.randomBytes.
 */
function generateCode(length = 8) {
    const bytes = crypto.randomBytes(length * 2); // Extra bytes for modulo bias reduction
    let code = '';
    for (let i = 0; i < length; i++) {
        // Use 2 bytes per character to minimise modulo bias
        const val = bytes.readUInt16BE(i * 2) % BASE32_ALPHABET.length;
        code += BASE32_ALPHABET[val];
    }
    return code;
}

/**
 * hashCode(plainCode)
 * Returns a bcrypt hash of the access code for secure storage.
 * Async — awaitable.
 */
async function hashCode(plainCode) {
    return bcrypt.hash(plainCode, BCRYPT_ROUNDS);
}

/**
 * verifyCode(plainCode, storedHash)
 * Returns true if plainCode matches the stored bcrypt hash.
 */
async function verifyCode(plainCode, storedHash) {
    if (!plainCode || !storedHash) return false;
    return bcrypt.compare(plainCode.toUpperCase(), storedHash);
}

/**
 * auditLog({ event, codeId, ip, userAgent, success, meta })
 * Persists an audit entry. Fire-and-forget safe (non-throwing).
 *
 * event values: 'GENERATE' | 'VERIFY_SUCCESS' | 'VERIFY_FAIL' | 'EXPIRE' | 'ROTATE'
 */
async function auditLog({ event, codeId = null, ip = 'unknown', userAgent = 'unknown', success = true, meta = {} }) {
    try {
        await CodeAuditLog.create({ event, codeId, ip, userAgent, success, meta });
    } catch (err) {
        // Non-blocking: log to console but don't throw
        console.error('[SecureCodeService] AuditLog write failed:', err.message);
    }
}

/**
 * formatExpiry(expiresAt)
 * Returns a human-readable string for the expiry time.
 */
function formatExpiry(expiresAt) {
    const ms   = expiresAt - Date.now();
    const hrs  = Math.floor(ms / 3_600_000);
    const mins = Math.floor((ms % 3_600_000) / 60_000);
    return `${hrs}h ${mins}m`;
}

module.exports = { generateCode, hashCode, verifyCode, auditLog, formatExpiry };
