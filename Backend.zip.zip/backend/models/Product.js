const mongoose = require('mongoose');

const ProductSchema = new mongoose.Schema({
    title: { type: String, required: true },
    thc: { type: String, required: true },
    price: { type: Number, required: true }, // In KSh
    color: { type: String, required: true }, // For UI styling
    category: { type: String, required: true },
    isInfused: { type: Boolean, default: false }
}, { timestamps: true });

module.exports = mongoose.model('Product', ProductSchema);
